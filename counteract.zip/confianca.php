<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Counteract - Balanceamento automático de pneus</title>

	<meta name="description" content="Counteract Balancing Beads é o Sistema mais avançado para balanceamento de rodagens existente no mercado mundial.">
	<meta name="keywords" content="balanceamento de roda, counteract balancing beads, sistema automático de balanceamento de pneus">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style>
		div#preloader { position: fixed; left: 0; top: 0; z-index: 999; width: 100%; height: 100%; overflow: visible; background: white no-repeat center center; }
	</style>


	<script type="text/javascript">
		var WaComponentContext = {};
	</script>

</head>
<body>
	<div id="preloader"></div>
	<a id="wa-anchor-top"></a>
	<div id="wa-container-wrapper-j5ju4lew45qi9c" >
		<div id="wa-container-j5ju4lew45qi9c" class="container  " >
			<div id="wa-row-j1336caw5mql1k" class="row row-align  ">
				<div class="wa-subpage-wrapper  col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
					<div id="wa-compsubpage-j1336f0b5gwul4">
						<div id="wa-row-j5ju8zzz489fsw" class="row row-align  ">
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-2 " >
								<div id="wa-sub-container-j3nrl7cw6o6keg">
									<div id="wa-row-j5ju8zzz489dq8" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j5ju8zzz5khqts" class="wa-comptext clearfix">
												<p><img style="margin: 10px;" src="wa_images/logomarca-topo-branca.png" width="116" height="39" alt="" title="" /></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-10 " >
								<div id="wa-sub-container-j3nrl7cy6o66ig">
									<div id="wa-row-j5ju8zzz489em8" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-compmenu-j5ju8zzz5kzwl4" class="wa-compmenu wa-menu-init">
												<nav class="navbar navbar-default wa-always-on-top wa-aot-fluid wa-menu-centered" style="margin:0px;">
													<div class="container-fluid">
														<!-- Brand and toggle get grouped for better mobile display -->
														<div class="navbar-header">
															<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#wa-collapse-wa-compmenu-j5ju8zzz5kzwl4" aria-expanded="false">
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
															</button>
															<a href="index.php" class="navbar-brand" style="font-weight:700">
															<span >Home</span>
															</a>
														</div>
														<div class="collapse navbar-collapse" id="wa-collapse-wa-compmenu-j5ju8zzz5kzwl4">
															<ul class="nav navbar-nav">
																<li class=""><a href="index.php#wa-anchor-j0x7aoo35smtts" class="scrollTo" >Empresa</a></li>
																<li class="active"><a href="" >Confiança</a></li>
																<li class=""><a href="garantia.php" >Garantia</a></li>
																<li class=""><a href="referencias.php" >Referências</a></li>
																<li class=""><a href="tabela-de-aplicacao.php" >Tabela de Aplicação</a></li>
																<li class=""><a href="faq.php" >FAQ</a></li>
																<li class=""><a href="localizacao.php" >Localização</a></li>
																<li class=""><a href="contato.php" >Contato</a></li>
															</ul>
														</div><!-- /.navbar-collapse -->
													</div><!-- /.container-fluid -->
												</nav>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j5ju4lf445qp7c" >
		<div id="wa-container-j5ju4lf445qp7c" class="container  " >
			<div id="wa-row-j134ltg65gmb7c" class="row row-align  ">
			</div>
			<div class="wa-container-vspacer col-xl-12"></div>
			<div id="wa-row-j134mioq5gmb7c" class="row  ">
				<div class="col-xl-12 wa-item-rowspacer"></div>
			</div>
			<div class="wa-container-vspacer col-xl-12"></div>
			<div id="wa-row-j1336ch95mqitk" class="row row-align  ">
				<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-6 " >
					<div id="wa-sub-container-j5ju4lf445qfy0">
						<div id="wa-row-j134bi353ycc00" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-comptext-j134bo5t6bcfew" class="wa-comptext clearfix">
									<p style="text-align: center;"><span style="font-size: 25px;"><strong>Confiança de quem é Lider !</strong></span></p>
								</div>
							</div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j13489x15mqmo8" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 "  data-ratioWidth="510" data-ratioHeight="310" >

								<img id="wa-compimage-j16jotjh451irk" alt="" class="wa-image-component " src="wa_images/mapa.png">

							</div>
						</div>
					</div>
				</div>
				<div class="clearfix visible-xs "></div>
				<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-6 " >
					<div id="wa-sub-container-j5ju4lf645qf68">
						<div id="wa-row-j1348aaz5mqlxk" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-comptext-j1349clw3x8q28" class="wa-comptext clearfix">
									<p style="text-align: justify; line-height: 1.63;"><span style="font-size: 16px;"><strong>Counteract Balancing Beads</strong> é o Sistema mais avançado para balanceamento de rodagens existente no mercado mundial.</span></p>
									<p style="text-align: justify; line-height: 1.63;"> </p>
									<p style="text-align: justify; line-height: 1.63;"><span style="font-size: 16px;">Desenvolvido e patenteado pela Counteract, que detém 100% da tecnologia aplicada, garante além do balanceamento perfeito dos pneus, uma maior durabilidade dos mesmos, e uma economia considerável no consumo de combustível do veículo que utiliza esse sistema.</span></p>
									<p style="text-align: justify; line-height: 1.63;"> </p>
									<p style="text-align: justify; line-height: 1.63;"><span style="font-size: 16px;">Com milhões de pneus balanceados em todo o mundo para concessionários e distribuidores, entusiastas off-road e grandes empresas de transporte, a <span style="font-size: 18px; color: #f33428;"><strong>Counteract</strong></span> garante <strong>Counteract Balancing Beads</strong> como o melhor método para balancear pneus e conjuntos de rodas.</span></p>
									<p style="text-align: justify; line-height: 1.63;"> </p>
									<p style="text-align: justify; line-height: 1.63;"><span style="font-size: 16px;"><span style="color: #f33428; font-size: 18px;"><strong>Counteract</strong></span>, 20 anos nas estradas por todo o Mundo !</span></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="wa-container-vspacer col-xl-12"></div>
			<div id="wa-row-j134ly5e5gm854" class="row  ">
				<div class="col-xl-12 wa-item-rowspacer"></div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j5ju4lf845qkko" >
		<div id="wa-container-j5ju4lf845qkko" class="container  " >
			<div id="wa-row-j1336cna5mql1k" class="row row-align  ">
				<div class="wa-subpage-wrapper  col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
					<div id="wa-compsubpage-j1336xxz450exc">
						<div id="wa-row-j5ju8zzz489fi8" class="row row-align  ">
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-4 col-md-4 col-lg-5 " >
								<div id="wa-sub-container-j132iqyp5hjwds">
									<div id="wa-row-j5ju8zzz489fnk" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-padwrapper-j5ju8zzz5l1k48" class="wa-comptext-padwrapper">
												<div id="wa-comptext-j5ju8zzz5l1k48" class="wa-comptext clearfix">
													<p><span style="font-size: 18px; color: #f33428;"><strong>COUNTERACT </strong></span></p>
													<p><span style="font-size: 16px; color: #f33428;"><strong><span style="color: #ffffff;">Balanceamento Automático Ltda</span></strong></span></p>
													<p><span style="font-size: 16px;"><strong> </strong></span></p>
													<p><strong>Rua Uberlândia, 752 A - Catarina</strong></p>
													<p><strong>Sete Lagoas - MG - cep: 35700-237</strong></p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-3 col-md-3 col-lg-4 " >
								<div id="wa-sub-container-j132iqyq5hjx5k">
									<div id="wa-row-j5ju8zzz489fy8" class="row row-align hidden-sm hidden-md ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j5ju8zzz5l1n8g" class="wa-comptext clearfix">
												<p><img style="margin: 10px;" src="wa_images/fone-email-imagem.png" width="35" height="35" alt="" title="" /> <span style="font-size: 16px;"><strong>(55) 31 3773 0654</strong></span></p>
												<p><img style="line-height: 1.43; margin: 10px;" src="wa_images/email-imagem.png" width="35" height="24" alt="" title="" /><strong> administrativo@counteract.com.br</strong></p>
											</div>
										</div>
									</div>
									<div class="wa-container-vspacer col-xl-12"></div>
									<div id="wa-row-j5ju8zzz489ha8" class="row row-align hidden-xs hidden-lg ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j5ju8zzz5l1pq8" class="wa-comptext clearfix">
												<p><img style="margin: 10px auto; display: block;" src="wa_images/fone-email-imagem.png" width="35" height="35" alt="" title="" /></p>
												<p style="text-align: center;"><span style="font-size: 16px;"><strong>(55) 31 3773 0654</strong></span></p>
												<p style="text-align: center;"><img style="line-height: 1.43; margin: 10px;" src="wa_images/email-imagem.png" width="35" height="24" alt="" title="" /></p>
												<p style="text-align: center;"><span style="font-size: 12px;"><strong>administrativo@counteract.com.br</strong></span></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-5 col-md-5 col-lg-3 " >
								<div id="wa-sub-container-j132iqyr5hk08o">
									<div id="wa-row-j5ju8zzz489hfk" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 "  data-ratioWidth="220" data-ratioHeight="72" >
											<div id="wa-compimage-padwrapper-j5ju8zzz43oe4w" class="wa-compimage-padwrapper">

												<img id="wa-compimage-j5ju8zzz43oe4w" alt="" class="wa-image-component " src="wa_images/logomarca-rodape.png">

											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j5ju8zzz489gow" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-comptext-j5ju8zzz5l1ld4" class="wa-comptext clearfix">
									<p><span style="font-size: 12px; color: #ffffff;"><strong><a style="color: #ffffff;" title="" href="http://www.loucosporsite.com"  target="_blank"><span style="font-size: 10px;">Desenvolvido por</span> Loucos por Site</a></strong></span></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a id="wa-anchor-bottom"></a>
	<link rel="stylesheet" href="wa_bootstrap/css/bootstrap.min.71.css"/>
	<link rel="stylesheet" href="wa_general.71.css"/>
	<link rel="stylesheet" href="wa_style_global.17.css"/>
	<link rel="stylesheet" href="wa_webfont_global.17.css"/>
	<link rel="stylesheet" href="wa_css/pages-page3_en.41.css"/>
	<link rel="stylesheet" href="wa_menu/menu.71.css"/>
	<script>
		document.getElementById("preloader").style.display = 'none';
	</script>
	<script src="wa_bootstrap/js/jquery.min.js?v=71" ></script>
	<script type="text/javascript">var wa$ = jQuery.noConflict()</script>
	<script src="wa_js/wa_bootstrap_util.js?v=71" ></script>
	<script src="wa_bootstrap/js/bootstrap.min.js?v=71" ></script>
	<script src="wa_js/waVariables_en.js?v=25" ></script>
	<script>
		WaContext.app_version="1.3.28"
		WaContext.app_revision="14dedb8"
		WaContext.preview=false
		WaPageContext.lang="en"
		WaPageContext.lang_filename="en"
	</script>
	<script src="wa_menu/wa_menu.js?v=71" ></script>
	<script src="wa_menu/wa_search.js?v=71" ></script>
	<script src="wa_js/jquery.validate.min.js?v=71" ></script>
	<script src="wa_js/wa_common.js?v=71" ></script>
	<script src="wa_js/parallax.js?v=71" ></script>
    <script type="text/javascript" src="https://counteract.com.br/online/php/app.php?widget-init.js"></script>
</body>
</html>