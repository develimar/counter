<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Counteract - Balanceamento automático de pneus</title>

	<meta name="description" content="Empresa especializada em balanceamento automático de pneus">
	<meta name="keywords" content="balanceamento de pneus, balanceamento automático, balanceamento automatico, alinhamento de pneus, counteract balancing, sistema de balanceamento inteligente">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style>
		div#preloader { position: fixed; left: 0; top: 0; z-index: 999; width: 100%; height: 100%; overflow: visible; background: white no-repeat center center; }
	</style>


	<script type="text/javascript">
		var WaComponentContext = {};
	</script>
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	
		<!--
			Supersized - Fullscreen Slideshow jQuery Plugin
			Version : 3.2.7
			Site	: www.buildinternet.com/project/supersized
			
			Author	: Sam Dunn
			Company : One Mighty Roar (www.onemightyroar.com)
			License : MIT License / GPL License
		-->
	
		<head>
	
			<title></title>
			<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
			
			<link rel="stylesheet" href="arquivo/css/supersized.css" type="text/css" media="screen" />
			<link rel="stylesheet" href="arquivo/theme/supersized.shutter.css" type="text/css" media="screen" />
			
		
			<script type="text/javascript" src="arquivo/js/jquery.easing.min.js"></script>
			<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
			
			<script type="text/javascript" src="arquivo/js/supersized.3.2.7.min.js"></script>
			<script type="text/javascript" src="arquivo/theme/supersized.shutter.min.js"></script>
			
			<script type="text/javascript">
				
				jQuery(function($){
					
					$.supersized({
					
						// Functionality
						slideshow               :   1,			// Slideshow on/off
						autoplay				:	1,			// Slideshow starts playing automatically
						start_slide             :   1,			// Start slide (0 is random)
						stop_loop				:	0,			// Pauses slideshow on last slide
						random					: 	0,			// Randomize slide order (Ignores start slide)
						slide_interval          :   3000,		// Length between transitions
						transition              :   6, 			// 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
						transition_speed		:	1000,		// Speed of transition
						new_window				:	1,			// Image links open in new window/tab
						pause_hover             :   0,			// Pause slideshow on hover
						keyboard_nav            :   1,			// Keyboard navigation on/off
						performance				:	1,			// 0-Normal, 1-Hybrid speed/quality, 2-Optimizes image quality, 3-Optimizes transition speed // (Only works for Firefox/IE, not Webkit)
						image_protect			:	1,			// Disables image dragging and right click with Javascript
																   
						// Size & Position						   
						min_width		        :   0,			// Min width allowed (in pixels)
						min_height		        :   0,			// Min height allowed (in pixels)
						vertical_center         :   1,			// Vertically center background
						horizontal_center       :   1,			// Horizontally center background
						fit_always				:	0,			// Image will never exceed browser width or height (Ignores min. dimensions)
						fit_portrait         	:   1,			// Portrait images will not exceed browser height
						fit_landscape			:   0,			// Landscape images will not exceed browser width
																   
						// Components							
						slide_links				:	'blank',	// Individual links for each slide (Options: false, 'num', 'name', 'blank')
						thumb_links				:	1,			// Individual thumb links for each slide
						thumbnail_navigation    :   0,			// Thumbnail navigation
						slides 					:  	[			// Slideshow Images
															{image : 'arquivo/img/1.jpg', title : '', thumb : 'img/1.jpg'},
															{image : 'arquivo/img/2.jpg', title : '', thumb : 'img/1.jpg'},
															{image : 'arquivo/img/3.jpg', title : '', thumb : 'img/1.jpg'},
	
														
													
															
													],
													
						// Theme Options			   
						progress_bar			:	1,			// Timer for each slide							
						mouse_scrub				:	0
						
					});
			    });
			    
			</script>
			
		</head>
		
	
	
	<body>
	
		<!--Demo styles (you can delete this block)-->
		
	
		
		<!--End of styles-->
	
		<!--Thumbnail Navigation-->
		<div id="prevthumb"></div>
		<div id="nextthumb"></div>
		
		<!--Arrow Navigation-->
		<a id="prevslide" class="load-item"></a>
		<a id="nextslide" class="load-item"></a>
		
		<div id="thumb-tray" class="load-item">
			<div id="thumb-back"></div>
			<div id="thumb-forward"></div>
		</div>
		
		
		
		
	
	</body>
	</html>

</head>
<body>
	<div id="preloader"></div>
	<a id="wa-anchor-top"></a>
	<div id="wa-container-wrapper-j5jtz8a9413jbc" >
		<div id="wa-container-j5jtz8a9413jbc" class="container  " >
			<div id="wa-row-j0x683hh5o95u8" class="row row-align  ">
				<div class="wa-subpage-wrapper  col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
					<div id="wa-compsubpage-j0x68hzd53pqa8">
						<div id="wa-row-j5ju8zyh489da8" class="row row-align  ">
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-2 " >
								<div id="wa-sub-container-j3nrl7cw6o6keg">
									<div id="wa-row-j5ju8zyh489c8w" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j5ju8zyh5khvtc" class="wa-comptext clearfix">
												<p><img style="margin: 10px;" src="wa_images/logomarca-topo-branca.png" width="116" height="39" alt="" title="" /></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-10 " >
								<div id="wa-sub-container-j3nrl7cy6o66ig">
									<div id="wa-row-j5ju8zyh489gjk" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-compmenu-j5ju8zyh5l0034" class="wa-compmenu wa-menu-init">
												<nav class="navbar navbar-default wa-always-on-top wa-aot-fluid wa-menu-centered" style="margin:0px;">
													<div class="container-fluid">
														<!-- Brand and toggle get grouped for better mobile display -->
														<div class="navbar-header">
															<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#wa-collapse-wa-compmenu-j5ju8zyh5l0034" aria-expanded="false">
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
															</button>
															<a href=""  class="navbar-brand"  style="font-weight:700">
															<span >Home</span>
															</a>
														</div>
														<div class="collapse navbar-collapse" id="wa-collapse-wa-compmenu-j5ju8zyh5l0034">
															<ul class="nav navbar-nav">
																<li class=""><a href="#wa-anchor-j0x7aoo35smtts"  class="scrollTo" >Empresa</a></li>
																<li class=""><a href="confianca.php" >Confiança</a></li>
																<li class=""><a href="garantia.php" >Garantia</a></li>
																<li class=""><a href="referencias.php" >Referências</a></li>
																<li class=""><a href="tabela-de-aplicacao.php" >Tabela de Aplicação</a></li>
																<li class=""><a href="faq.php" >FAQ</a></li>
																<li class=""><a href="localizacao.php" >Localização</a></li>
																<li class=""><a href="contato.php" >Contato</a></li>
															</ul>
														</div><!-- /.navbar-collapse -->
													</div><!-- /.container-fluid -->
												</nav>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j5jtz8b2413kuw" >
		<div id="wa-container-j5jtz8b2413kuw" class="container  " >
			<div id="wa-row-j0x8z9oy4zt23k" class="row  ">
				<div class="col-xl-12 wa-item-rowspacer"></div>
			</div>
			<div class="wa-container-vspacer col-xl-12"></div>
			<div id="wa-row-j0zrzuuy8khmc" class="row row-align  ">
				<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
					<div id="wa-sub-container-j5jtz8b245qnns">
						<div id="wa-row-j0zrzuuv6bgcww" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-comptext-j0zs0zoa85g420" class="wa-comptext clearfix">
									<p style="text-align: center;"><span style="color: #ffffff;"><strong>SEJA BEM VINDO A</strong></span></p>
									<p style="text-align: center;"> <img style="line-height: 1.43; margin: 10px;" src="wa_images/logomarca-slide_(1).png" width="307" height="100" alt="" title="" /></p>
									<p style="text-align: center;"><span style="color: #ffffff;"><strong>TESTADA E APROVADA EM TODO O MUNDO</strong></span></p>
								</div>
							</div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j0zs7kxp81za7k" class="row  ">
							<div class="col-xl-12 wa-item-rowspacer"></div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j0zs0i9x3ytf0g" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-compbutton-j0zs5g5y7ymads-halign">	<a id="wa-compbutton-j0zs5g5y7ymads" href="contato.php" class="btn btn-primary wa-compbutton" >ENTRE EM CONTATO CONOSCO</a>
								</div></div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j0zs0ldv3yteio" class="row  ">
							<div class="col-xl-12 wa-item-rowspacer"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j5jtz8b545qkko" >
		<div id="wa-container-j5jtz8b545qkko" class="container  " >
			<div id="wa-row-j128p43h4r6yf4" class="row row-align  ">
			</div>
			<div class="wa-container-vspacer col-xl-12"></div>
			<div id="wa-row-j0x907vg5s8giw" class="row  ">
				<div class="col-xl-12 wa-item-rowspacer"></div>
			</div>
			<div class="wa-container-vspacer col-xl-12"></div>
			<div id="wa-row-j0x6avwk5o92fk" class="row row-align  ">
				<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-6 " >
					<div id="wa-sub-container-j5jtz8b545qfy0">
						<div id="wa-row-j0x6dikg5o92fk" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 "  data-ratioWidth="550" data-ratioHeight="400" >

								<img id="wa-compimage-j17r2qkx545pp4" alt="" class="wa-image-component " src="wa_images/rodas.jpg">

							</div>
						</div>
					</div>
				</div>
				<div class="clearfix visible-xs "></div>
				<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-6 " >
					<div id="wa-sub-container-j5jtz8b545qhhk">
						<div id="wa-row-j0x6dj8i5o90cw" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 "  data-ratioWidth="307" data-ratioHeight="100" >
							<div id="wa-anchor-j0x7aoo35smtts"></div>
								<div id="wa-compimage-padwrapper-j0x7aoo55smx2g" class="wa-compimage-padwrapper">

									<img id="wa-compimage-j0x7aoo55smx2g" alt="" class="wa-image-component " src="wa_images/logomarca.png">

								</div>
							</div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j0x84ein5lhre8" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-comptext-j0x84hoo5r5qpk" class="wa-comptext clearfix">
									<p style="text-align: justify; line-height: 1.55;"><span style="font-size: 16px;">A <span style="font-size: 18px; color: #f33428;"><strong>Counteract</strong></span> desenvolveu para o mercado automobilístico, o <strong>Sistema de Balanceamento Inteligente</strong>, o mais avançado sistema de balanceamento de rodagem, com tecnologia de ponta e 100% própria, garantindo confiabilidade e segurança.</span></p>
									<p style="text-align: justify; line-height: 1.55;"><span style="font-size: 16px;">As vantagens que esse Sistema oferece são:</span></p>
									<ul>
									<li style="text-align: justify;">Elimina as vibrações na direção/volante e suspensão;</li>
									<li style="text-align: justify;">Evita o desgaste irregular dos pneus;</li>
									<li style="text-align: justify;">Aumenta a vida útil do pneu;</li>
									<li style="text-align: justify;">Balanceamento constante;</li>
									<li style="text-align: justify;">Aumenta a durabilidade do sistema de suspensão do veículo;</li>
									<li style="text-align: justify;">Aumenta a preservação da carcaça do pneu para recapagem;</li>
									<li style="text-align: justify;">Produto atóxico, não oferecendo riscos a quem o manipula, nem poluindo o meio ambiente;</li>
									<li style="text-align: justify;">Oferece fácil instalação, não exigindo conhecimentos técnicos para sua utilização;</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j5jtz8b745qp7c" >
		<div id="wa-container-j5jtz8b745qp7c" class="container  " >
			<div id="wa-row-j0x917xe5n5ks0" class="row  ">
				<div class="col-xl-12 wa-item-rowspacer"></div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j5jtz8b745qjsw" >
		<div id="wa-container-j5jtz8b745qjsw" class="container  " >
			<div id="wa-row-j0x6aw645o90i8" class="row row-align  ">
				<div class="wa-subpage-wrapper  col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
					<div id="wa-compsubpage-j0x6cd6l2sm080">
						<div id="wa-row-j5ju8zz3489dvk" class="row row-align  ">
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-4 col-md-4 col-lg-5 " >
								<div id="wa-sub-container-j132iqyp5hjwds">
									<div id="wa-row-j5ju8zz3489by8" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-padwrapper-j5ju8zz35khlu8" class="wa-comptext-padwrapper">
												<div id="wa-comptext-j5ju8zz35khlu8" class="wa-comptext clearfix">
													<p><span style="font-size: 18px; color: #f33428;"><strong>COUNTERACT </strong></span></p>
													<p><span style="font-size: 16px; color: #f33428;"><strong><span style="color: #ffffff;">Balanceamento Automático Ltda</span></strong></span></p>
													<p><span style="font-size: 16px;"><strong> </strong></span></p>
													<p><strong>Rua Uberlândia, 752 A - Catarina</strong></p>
													<p><strong>Sete Lagoas - MG - cep: 35700-237</strong></p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-3 col-md-3 col-lg-4 " >
								<div id="wa-sub-container-j132iqyq5hjx5k">
									<div id="wa-row-j5ju8zz3489eww" class="row row-align hidden-sm hidden-md ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j5ju8zz35khx28" class="wa-comptext clearfix">
												<p><img style="margin: 10px;" src="wa_images/fone-email-imagem.png" width="35" height="35" alt="" title="" /> <span style="font-size: 16px;"><strong>(55) 31 3773 0654</strong></span></p>
												<p><img style="line-height: 1.43; margin: 10px;" src="wa_images/email-imagem.png" width="35" height="24" alt="" title="" /><strong> administrativo@counteract.com.br</strong></p>
											</div>
										</div>
									</div>
									<div class="wa-container-vspacer col-xl-12"></div>
									<div id="wa-row-j5ju8zz3489f28" class="row row-align hidden-xs hidden-lg ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j5ju8zz35khxoo" class="wa-comptext clearfix">
												<p><img style="margin: 10px auto; display: block;" src="wa_images/fone-email-imagem.png" width="35" height="35" alt="" title="" /></p>
												<p style="text-align: center;"><span style="font-size: 16px;"><strong>(55) 31 3773 0654</strong></span></p>
												<p style="text-align: center;"><img style="line-height: 1.43; margin: 10px;" src="wa_images/email-imagem.png" width="35" height="24" alt="" title="" /></p>
												<p style="text-align: center;"><span style="font-size: 12px;"><strong>administrativo@counteract.com.br</strong></span></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-5 col-md-5 col-lg-3 " >
								<div id="wa-sub-container-j132iqyr5hk08o">
									<div id="wa-row-j5ju8zz3489d4w" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 "  data-ratioWidth="220" data-ratioHeight="72" >
											<div id="wa-compimage-padwrapper-j5ju8zz343oes8" class="wa-compimage-padwrapper">

												<img id="wa-compimage-j5ju8zz343oes8" alt="" class="wa-image-component " src="wa_images/logomarca-rodape.png">

											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j5ju8zz3489c3k" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-comptext-j5ju8zz35khmgo" class="wa-comptext clearfix">
									<p><span style="font-size: 12px; color: #ffffff;"><strong><a style="color: #ffffff;" title="" href="http://www.loucosporsite.com"  target="_blank"><span style="font-size: 10px;">Desenvolvido por</span> Loucos por Site</a></strong></span></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a id="wa-anchor-bottom"></a>
	<link rel="stylesheet" href="wa_bootstrap/css/bootstrap.min.71.css"/>
	<link rel="stylesheet" href="wa_general.71.css"/>
	<link rel="stylesheet" href="wa_style_global.17.css"/>
	<link rel="stylesheet" href="wa_webfont_global.17.css"/>
	<link rel="stylesheet" href="wa_css/pages-home_en.150.css"/>
	<link rel="stylesheet" href="wa_menu/menu.71.css"/>
	<script>
		document.getElementById("preloader").style.display = 'none';
	</script>
	<script src="wa_bootstrap/js/jquery.min.js?v=71" ></script>
	<script type="text/javascript">var wa$ = jQuery.noConflict()</script>
	<script src="wa_js/wa_bootstrap_util.js?v=71" ></script>
	<script src="wa_bootstrap/js/bootstrap.min.js?v=71" ></script>
	<script src="wa_js/waVariables_en.js?v=25" ></script>
	<script>
		WaContext.app_version="1.3.28"
		WaContext.app_revision="14dedb8"
		WaContext.preview=false
		WaPageContext.lang="en"
		WaPageContext.lang_filename="en"
	</script>
	<script src="wa_menu/wa_menu.js?v=71" ></script>
	<script src="wa_menu/wa_search.js?v=71" ></script>
	<script src="wa_js/jquery.validate.min.js?v=71" ></script>
	<script src="wa_js/wa_common.js?v=71" ></script>
	<script src="wa_js/parallax.js?v=71" ></script>
    <script type="text/javascript" src="https://counteract.com.br/online/php/app.php?widget-init.js"></script>
</body>
</html>