<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>contato</title>

	<meta name="description" content="Entre em contato com a Counteract, fone 31 3773 0654">
	<meta name="keywords" content="">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style>
		div#preloader { position: fixed; left: 0; top: 0; z-index: 999; width: 100%; height: 100%; overflow: visible; background: white no-repeat center center; }
	</style>


	<script type="text/javascript">
		var WaComponentContext = {};
	</script>

</head>
<body>
	<div id="preloader"></div>
	<a id="wa-anchor-top"></a>
	<div id="wa-container-wrapper-j3ns7otk6o6f00" >
		<div id="wa-container-j3ns7otk6o6f00" class="container  " >
			<div id="wa-row-j0yn9b8f451sv4" class="row row-align  ">
				<div class="wa-subpage-wrapper  col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
					<div id="wa-compsubpage-j0yn9k9q3i82q0">
						<div id="wa-row-j3nsxrsb6l7qxc" class="row row-align  ">
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-2 " >
								<div id="wa-sub-container-j3nrl7cw6o6keg">
									<div id="wa-row-j3nsxrsb6l7rdc" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j3nsxrsb7dytyg" class="wa-comptext clearfix">
												<p><img style="margin: 10px;" src="wa_images/logomarca-topo-branca.png" width="116" height="39" alt="" title="" /></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-6 col-md-6 col-lg-10 " >
								<div id="wa-sub-container-j3nrl7cy6o66ig">
									<div id="wa-row-j3nsxrsb6l7rio" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-compmenu-j3nsxrsb7i52uw" class="wa-compmenu wa-menu-init">
												<nav class="navbar navbar-default wa-always-on-top wa-aot-fluid wa-menu-centered" style="margin:0px;">
													<div class="container-fluid">
														<!-- Brand and toggle get grouped for better mobile display -->
														<div class="navbar-header">
															<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#wa-collapse-wa-compmenu-j3nsxrsb7i52uw" aria-expanded="false">
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
															</button>
															<a href="index.php" class="navbar-brand" style="font-weight:700">
															<span >Home</span>
															</a>
														</div>
														<div class="collapse navbar-collapse" id="wa-collapse-wa-compmenu-j3nsxrsb7i52uw">
															<ul class="nav navbar-nav">
																<li class=""><a href="index.php#wa-anchor-j0x7aoo35smtts" class="scrollTo" >Empresa</a></li>
																<li class=""><a href="confianca.php" >Confiança</a></li>
																<li class=""><a href="garantia.php" >Garantia</a></li>
																<li class=""><a href="referencias.php" >Referências</a></li>
																<li class=""><a href="tabela-de-aplicacao.php" >Tabela de Aplicação</a></li>
																<li class=""><a href="faq.php" >FAQ</a></li>
																<li class=""><a href="localizacao.php" >Localização</a></li>
																<li class="active"><a href="" >Contato</a></li>
															</ul>
														</div><!-- /.navbar-collapse -->
													</div><!-- /.container-fluid -->
												</nav>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j3ns7ots6o5zkg" >
		<div id="wa-container-j3ns7ots6o5zkg" class="container  " >
			<div id="wa-row-j0ynail1451xwg" class="row row-align  ">
				<div class=" col-xs-12 col-sm-6 col-md-6 col-lg-6 "  data-ratioWidth="420" data-ratioHeight="310" >
					<div id="wa-compimage-padwrapper-j0ynuqr76pvz7k" class="wa-compimage-padwrapper">

						<img id="wa-compimage-j0ynuqr76pvz7k" alt="" class="wa-image-component " src="wa_images/telefonista.jpg">

					</div>
				</div>
				<div class="clearfix visible-xs "></div>
				<div class=" col-xs-12 col-sm-6 col-md-6 col-lg-6 " >
					<div id="wa-compcontactform-padwrapper-j0ynakjk6gb0n4" class="wa-compcontactform-padwrapper">
						<div id="wa-compcontactform-j0ynakjk6gb0n4" class="well well-sm wa-compcontactform" style="margin:0px">
							<form id="wa-form-j0ynakji6gawd4" class="form-horizontal" method="post" enctype="multipart/form-data" >
						
								<fieldset>
									<div class="form-group">
						
										<div class="col-md-12">
											<div class="header">Entre em contato conosco</div>
										</div>
									</div>
									<div class="form-group">
						
										<div class="col-md-12">
											<input id="firstname_field_1" name="firstname_field_1" class="form-control" type="text"  placeholder="nome" required maxlength=30 >
										</div>
									</div>
									<div class="form-group">
						
										<div class="col-md-12">
											<input id="field_2" name="field_2" class="form-control" type="text"  placeholder="empresa" maxlength=50 >
										</div>
									</div>
									<div class="form-group">
						
										<div class="col-md-12">
											<input id="mail_field_3" name="mail_field_3" class="form-control" type="email"  placeholder="email" required maxlength=50 >
										</div>
									</div>
									<div class="form-group">
						
										<div class="col-md-12">
											<input id="phone_field_4" name="phone_field_4" class="form-control" type="text"  placeholder="telefone" required maxlength=30 >
										</div>
									</div>
									<div class="form-group">
						
										<div class="col-md-12">
											<textarea id="field_5" class="form-control" name="field_5"  placeholder="Mensagem" rows="7" required maxlength=500 ></textarea>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-12 text-center">
											<button type="submit" class="btn btn-primary " >Send</button>
										</div>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="wa-container-wrapper-j3ns7ott6o6gjk" >
		<div id="wa-container-j3ns7ott6o6gjk" class="container  " >
			<div id="wa-row-j0zcj9tl40drqo" class="row row-align  ">
				<div class="wa-subpage-wrapper  col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
					<div id="wa-compsubpage-j0zcjcwf3vmas8">
						<div id="wa-row-j3nsxrsq505mfs" class="row row-align  ">
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-4 col-md-4 col-lg-5 " >
								<div id="wa-sub-container-j132iqyp5hjwds">
									<div id="wa-row-j3nsxrsq505kns" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-padwrapper-j3nsxrsq7dyspk" class="wa-comptext-padwrapper">
												<div id="wa-comptext-j3nsxrsq7dyspk" class="wa-comptext clearfix">
													<p><span style="font-size: 18px; color: #f33428;"><strong>COUNTERACT </strong></span></p>
													<p><span style="font-size: 16px; color: #f33428;"><strong><span style="color: #ffffff;">Balanceamento Automático Ltda</span></strong></span></p>
													<p><span style="font-size: 16px;"><strong> </strong></span></p>
													<p><strong>Rua Uberlândia, 752 A - Catarina</strong></p>
													<p><strong>Sete Lagoas - MG - cep: 35700-237</strong></p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-3 col-md-3 col-lg-4 " >
								<div id="wa-sub-container-j132iqyq5hjx5k">
									<div id="wa-row-j3nsxrsq505rh4" class="row row-align hidden-sm hidden-md ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j3nsxrsr7dyq7s" class="wa-comptext clearfix">
												<p><img style="margin: 10px;" src="wa_images/fone-email-imagem.png" width="35" height="35" alt="" title="" /> <span style="font-size: 16px;"><strong>(55) 31 3773 0654</strong></span></p>
												<p><img style="line-height: 1.43; margin: 10px;" src="wa_images/email-imagem.png" width="35" height="24" alt="" title="" /><strong> administrativo@counteract.com.br</strong></p>
											</div>
										</div>
									</div>
									<div class="wa-container-vspacer col-xl-12"></div>
									<div id="wa-row-j3nsxrsq505sd4" class="row row-align hidden-xs hidden-lg ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
											<div id="wa-comptext-j3nsxrsr7dz0tc" class="wa-comptext clearfix">
												<p><img style="margin: 10px auto; display: block;" src="wa_images/fone-email-imagem.png" width="35" height="35" alt="" title="" /></p>
												<p style="text-align: center;"><span style="font-size: 16px;"><strong>(55) 31 3773 0654</strong></span></p>
												<p style="text-align: center;"><img style="line-height: 1.43; margin: 10px;" src="wa_images/email-imagem.png" width="35" height="24" alt="" title="" /></p>
												<p style="text-align: center;"><span style="font-size: 12px;"><strong>administrativo@counteract.com.br</strong></span></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix visible-xs "></div>
							<div class="wa-subcontainer-wrapper  col-xs-12 col-sm-5 col-md-5 col-lg-3 " >
								<div id="wa-sub-container-j132iqyr5hk08o">
									<div id="wa-row-j3nsxrsq505pjs" class="row row-align  ">
										<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 "  data-ratioWidth="220" data-ratioHeight="72" >
											<div id="wa-compimage-padwrapper-j3nsxrsr6ivs08" class="wa-compimage-padwrapper">

												<img id="wa-compimage-j3nsxrsr6ivs08" alt="" class="wa-image-component " src="wa_images/logomarca-rodape.png">

											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="wa-container-vspacer col-xl-12"></div>
						<div id="wa-row-j3nsxrsq505pug" class="row row-align  ">
							<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 " >
								<div id="wa-comptext-j3nsxrsr7dyqu8" class="wa-comptext clearfix">
									<p><span style="font-size: 12px; color: #ffffff;"><strong><a style="color: #ffffff;" title="" href="http://www.loucosporsite.com"  target="_blank"><span style="font-size: 10px;">Desenvolvido por</span> Loucos por Site</a></strong></span></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a id="wa-anchor-bottom"></a>
	<link rel="stylesheet" href="wa_bootstrap/css/bootstrap.min.71.css"/>
	<link rel="stylesheet" href="wa_general.71.css"/>
	<link rel="stylesheet" href="wa_style_global.17.css"/>
	<link rel="stylesheet" href="wa_webfont_global.17.css"/>
	<link rel="stylesheet" href="wa_css/pages-page_en.40.css"/>
	<link rel="stylesheet" href="wa_menu/menu.71.css"/>
	<script>
		document.getElementById("preloader").style.display = 'none';
	</script>
	<script src="wa_bootstrap/js/jquery.min.js?v=71" ></script>
	<script type="text/javascript">var wa$ = jQuery.noConflict()</script>
	<script src="wa_js/wa_bootstrap_util.js?v=71" ></script>
	<script src="wa_bootstrap/js/bootstrap.min.js?v=71" ></script>
	<script src="wa_js/waVariables_en.js?v=25" ></script>
	<script>
		WaContext.app_version="1.3.28"
		WaContext.app_revision="14dedb8"
		WaContext.preview=false
		WaPageContext.lang="en"
		WaPageContext.lang_filename="en"
	</script>
	<script src="wa_menu/wa_menu.js?v=71" ></script>
	<script src="wa_menu/wa_search.js?v=71" ></script>
	<script src="https://www.google.com/recaptcha/api.js?render=explicit" async defer ></script>
	<script src="wa_js/wa_form.js?v=71" ></script>
	<script src="wa_js/jquery.validate.min.js?v=71" ></script>
	<script src="wa_js/wa_common.js?v=71" ></script>
	<script src="wa_js/parallax.js?v=71" ></script>
    <script type="text/javascript" src="https://counteract.com.br/online/php/app.php?widget-init.js"></script>
</body>
</html>