<?php

return array(

    'headerHeight' => 55,
    'widgetWidth'  => 370,
    'widgetHeight' => 411,
);